let organization = {
    name: "story",
    address: {
        city: "bangalore",
        street: "abcd",
        state: "Karnataka",
        pin_code: 123456
    }
};

let { pin_code } = organization;

console.log( pin_code);