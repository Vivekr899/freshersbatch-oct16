class Fibanoci{
    private PrevNo;
    
}