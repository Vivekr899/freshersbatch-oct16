const a = 10;
console.log(a);
a=11;
console.log(a);