let order={
    id:1234,
    title:"grocery",
    price:128
};
function printOrder(){
    console.log(order);
}
printOrder();
function getPrice(){
    console.log(order.price);
}
getPrice();
